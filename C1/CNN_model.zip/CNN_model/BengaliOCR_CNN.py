import numpy as np 
import pandas as pd
from tqdm.auto import tqdm
from glob import glob
import time, gc
import cv2
import os
import datetime
import matplotlib.image as mpimg

from utils import *
from view_data import *
from preprocessing import *
from model import *


import tensorflow as tf
import tensorflow.keras as keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, Flatten, Input
from tensorflow.keras.layers import Conv2D, MaxPooling2D
from sklearn.model_selection import train_test_split


IMG_SIZE=64
N_CHANNELS=1


#Import data
train_df_, test_df, class_map_df, sample_sub_df = read_input_files()

#clean df format
train_df_ = train_df_.drop(['grapheme'], axis=1, inplace=False)
train_df_[['grapheme_root', 'vowel_diacritic', 'consonant_diacritic']] = train_df_[[
    'grapheme_root', 'vowel_diacritic', 'consonant_diacritic']].astype('uint8')


# Set a learning rate annealer
learning_rate_reduction_root = ReduceLROnPlateau(monitor='dense_3_accuracy', 
                                            patience=3, 
                                            verbose=0,
                                            factor=0.5, 
                                            min_lr=0.00001)
learning_rate_reduction_vowel = ReduceLROnPlateau(monitor='dense_4_accuracy', 
                                            patience=3, 
                                            verbose=0,
                                            factor=0.5, 
                                            min_lr=0.00001)
learning_rate_reduction_consonant = ReduceLROnPlateau(monitor='dense_5_accuracy', 
                                            patience=3, 
                                            verbose=0,
                                            factor=0.5, 
                                            min_lr=0.00001)


batch_size = 64#256
epochs = 5
HEIGHT = 137
WIDTH = 236
results = {}


### Adapt CMATER Model
CMATER_model = keras.models.load_model('CMATERdb3.1.3.2/CMATER_model_30.h5')

head_root = Dense(168, activation = 'softmax',name="head_root")(CMATER_model.layers[-2].output)
head_vowel = Dense(11, activation = 'softmax',name="head_vowel")(CMATER_model.layers[-2].output)
head_consonant = Dense(7, activation = 'softmax',name="head_consonant")(CMATER_model.layers[-2].output)

model = keras.Model(inputs=CMATER_model.input, outputs=[head_root, head_vowel, head_consonant])
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])



### Kaggle Data
histories = []



# Data augmentation

for i in range(4):
    print("i", i)

    # Load data
    train_df = pd.merge(pd.read_feather(f'bengaliaicv19feather/train_image_data_{i}.feather'), train_df_, on='image_id').drop(['image_id'], axis=1)
    X_train = train_df.drop(['grapheme_root', 'vowel_diacritic', 'consonant_diacritic'], axis=1)
    X_train = resize(X_train)/255


    # CNN takes images in shape `(batch_size, h, w, channels)`, so reshape the images
    X_train = X_train.values.reshape(-1, IMG_SIZE, IMG_SIZE, N_CHANNELS)

    Y_train_root = pd.get_dummies(train_df['grapheme_root']).values
    Y_train_vowel = pd.get_dummies(train_df['vowel_diacritic']).values
    Y_train_consonant = pd.get_dummies(train_df['consonant_diacritic']).values


    # Divide the data into training and validation set
    x_train, x_test, y_train_root, y_test_root, y_train_vowel, y_test_vowel, y_train_consonant, y_test_consonant = train_test_split(X_train, Y_train_root, Y_train_vowel, Y_train_consonant, test_size=0.08, random_state=666)
    del train_df
    del train_df_
    del X_train
    del Y_train_root, Y_train_vowel, Y_train_consonant
    
    datagen = MultiOutputDataGenerator(
        featurewise_center=False,                                   # set input mean to 0 over the dataset
        samplewise_center=False,                                    # set each sample mean to 0
        featurewise_std_normalization=False,                        # divide inputs by std of the dataset
        samplewise_std_normalization=False,                         # divide each input by its std
        zca_whitening=False,                                        # apply ZCA whitening
        rotation_range=0,           # randomly rotate images in the range (degrees, 0 to 180)
        zoom_range = 0,                    # Randomly zoom image 
        width_shift_range= 0,           # randomly shift images horizontally (fraction of total width)
        height_shift_range= 0,          # randomly shift images vertically (fraction of total height)
        horizontal_flip=False,                                      # randomly flip images
        vertical_flip=False)                                        # randomly flip images


    # This will just calculate parameters required to augment the given data. This won't perform any augmentations
    datagen.fit(x_train)


    # Fit the model
    history = model.fit_generator(datagen.flow(x_train, {'head_root': y_train_root, 'head_vowel': y_train_vowel, 'head_consonant': y_train_consonant}, batch_size=batch_size),
                              epochs = epochs, verbose = 0, validation_data = (x_test, [y_test_root, y_test_vowel, y_test_consonant]), 
                              steps_per_epoch=x_train.shape[0] // batch_size, 
                              callbacks=[learning_rate_reduction_root, learning_rate_reduction_vowel, learning_rate_reduction_consonant])

    histories.append(history)



    # Delete to reduce memory usage
    del x_train
    del x_test
    del y_train_root
    del y_test_root
    del y_train_vowel
    del y_test_vowel
    del y_train_consonant
    del y_test_consonant
    gc.collect()


model.save('model_incl_CMATER_30.h5')
